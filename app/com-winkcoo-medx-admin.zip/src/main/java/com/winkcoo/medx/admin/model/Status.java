package com.winkcoo.medx.admin.model;

public class Status {
    int status;

    public int isStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
